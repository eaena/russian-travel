---
name: Feature request
about: Suggest an idea

---

A clear and concise description of what you want to happen or see change.

**Additional context**
- Alternatives you've considered
- Add any other context or screenshots about the feature request here.
- If this is related to a problem, describe the problem.
