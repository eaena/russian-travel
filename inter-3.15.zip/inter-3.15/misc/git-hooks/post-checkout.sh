#!/bin/bash -e
bash init.sh
